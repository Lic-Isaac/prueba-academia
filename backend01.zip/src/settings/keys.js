export const clave = {
    key:"clavesecreta2024"
}